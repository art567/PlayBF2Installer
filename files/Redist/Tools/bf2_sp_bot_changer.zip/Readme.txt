===========================================
BF2 SP Bot Changer v2.1
===========================================

BF2 SP Bot Changer is a tool to change the AI settings for BF2, 
including the orginal BF2 and all single player mods. 
The user interface is easy to use, and can choose which mods
you want to change settings for. 
BF2 SP Bot Changer autodetects your BF2 folder from registry, 
so no special installation is needed.

How to install:
===========================================
1. Extract the file to anywhere.
2. Finished
===========================================

How to use:
===========================================
BF2 SP Bot Changer will get the BF2 folder from registry, if no key is found,
you will be asked to specify your BF2 directory. All single player mods will automaticly be detected
and placed in a list whit their respective names. You can change the settings by draging the two slidebars.
To save the settings to selected mod, press the 'Save Settings' button. 
The 'Run BF2 Mod' button will run the selected mod. The amount of bots does not include you.
===========================================

Change log:
===========================================
New features in v2.1:
 # Autodecting of the BF2 directory
 # Ballontips
 # SP mods listed by names, instead of directory name
 # 40% smaller exe
 # Up to 255 bots!!
 # Bugs fixed

New features in v2.0:
 # Change settings for selected SP mod
 # Added option to change bot skils 
===========================================

!Sorry for my bad english!
  
===========================================
Made by and for BF2 community

Use and share it freely, no license or copyright! :)
Reistribute freely if you want.
I am not responsible for any damage or lose of data of using this program.
===========================================
� October 2005